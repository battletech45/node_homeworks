const express = require('express');
const app = express();
const port = 3000;

// Configure express
app.set('view engine', 'pug');
app.use(express.urlencoded({ extended: true }));

// Add this line to serve static files
app.use(express.static('public'));

// Store users in memory (in a real app, you'd use a database)
const users = [];

// Routes
app.get('/', (req, res) => {
  res.render('index');
});

app.post('/users', (req, res) => {
  const name = req.body.name;
  
  if (name && name.trim()) {
    users.push(name.trim());
    res.render('users', { users, error: null });
  } else {
    res.render('users', { users, error: 'Please provide a valid name' });
  }
});

app.get('/users', (req, res) => {
  res.render('users', { users, error: null });
});

app.listen(port, () => {
  console.log(`App listening at http://localhost:${port}`);
});
